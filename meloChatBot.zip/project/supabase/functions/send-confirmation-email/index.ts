import { serve } from 'https://deno.land/std@0.168.0/http/server.ts'

const RESEND_API_KEY = Deno.env.get('RESEND_API_KEY')

interface EmailData {
  to: string
  name: string
  date: string
  time: string
  type: string
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: { 'Access-Control-Allow-Origin': '*' } })
  }

  try {
    const { to, name, date, time, type } = await req.json() as EmailData

    const res = await fetch('https://api.resend.com/emails', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${RESEND_API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        from: 'Melody <appointments@yourdomain.com>',
        to: [to],
        subject: 'Your Appointment Confirmation',
        html: `
          <h1>Appointment Confirmation</h1>
          <p>Dear ${name},</p>
          <p>Your appointment has been scheduled successfully!</p>
          <p><strong>Details:</strong></p>
          <ul>
            <li>Date: ${date}</li>
            <li>Time: ${time}</li>
            <li>Type: ${type}</li>
          </ul>
          <p>If you need to reschedule or have any questions, please reply to this email.</p>
          <p>Best regards,<br>Melody</p>
        `,
      }),
    })

    const data = await res.json()

    return new Response(JSON.stringify(data), {
      headers: { 'Content-Type': 'application/json' },
      status: 200,
    })
  } catch (error) {
    return new Response(JSON.stringify({ error: error.message }), {
      headers: { 'Content-Type': 'application/json' },
      status: 500,
    })
  }
})