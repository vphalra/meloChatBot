/*
  # Add email notifications system

  1. New Tables
    - `email_notifications`
      - `id` (uuid, primary key)
      - `appointment_id` (uuid, references appointments)
      - `email_to` (text)
      - `email_subject` (text)
      - `email_content` (text)
      - `status` (text)
      - `created_at` (timestamp)
      - `sent_at` (timestamp)

  2. Changes
    - Add email notification tracking
    - Add fallback for failed email sends
*/

-- Create email notifications table
CREATE TABLE IF NOT EXISTS email_notifications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  appointment_id uuid REFERENCES appointments(id),
  email_to text NOT NULL,
  email_subject text NOT NULL,
  email_content text NOT NULL,
  status text NOT NULL DEFAULT 'pending',
  created_at timestamptz DEFAULT now(),
  sent_at timestamptz,
  retry_count int DEFAULT 0,
  last_error text
);

ALTER TABLE email_notifications ENABLE ROW LEVEL SECURITY;

-- Allow insert for authenticated users
CREATE POLICY "Allow insert email notifications"
  ON email_notifications
  FOR INSERT
  TO public
  WITH CHECK (true);

-- Allow users to view their own notifications
CREATE POLICY "Users can view their notifications"
  ON email_notifications
  FOR SELECT
  TO public
  USING (email_to IS NOT NULL);

-- Function to create email notification
CREATE OR REPLACE FUNCTION create_appointment_notification()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO email_notifications (
    appointment_id,
    email_to,
    email_subject,
    email_content
  ) VALUES (
    NEW.id,
    NEW.user_email,
    'Your Appointment Confirmation',
    format(
      'Dear %s,

Your appointment has been scheduled successfully!

Details:
- Date: %s
- Time: %s
- Type: %s

If you need to reschedule or have any questions, please contact us.

Best regards,
Melody',
      NEW.name,
      NEW.date,
      NEW.time,
      NEW.type
    )
  );
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger to create email notification when appointment is created
DROP TRIGGER IF EXISTS appointment_notification_trigger ON appointments;
CREATE TRIGGER appointment_notification_trigger
  AFTER INSERT ON appointments
  FOR EACH ROW
  EXECUTE FUNCTION create_appointment_notification();