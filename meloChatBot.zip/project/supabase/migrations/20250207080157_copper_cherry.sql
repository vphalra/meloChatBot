/*
  # Create appointments system

  1. New Tables
    - `appointments`
      - `id` (uuid, primary key)
      - `user_email` (text, for non-authenticated users)
      - `date` (date)
      - `time` (time)
      - `type` (text)
      - `name` (text)
      - `phone` (text)
      - `insurance` (text)
      - `status` (text)
      - `created_at` (timestamptz)
  
  2. Security
    - Enable RLS on `appointments` table
    - Add policy for public access (since we're handling non-authenticated users)
*/

CREATE TABLE IF NOT EXISTS appointments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_email text NOT NULL,
  date date NOT NULL,
  time time NOT NULL,
  type text NOT NULL,
  name text NOT NULL,
  phone text NOT NULL,
  insurance text,
  status text NOT NULL DEFAULT 'pending',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE appointments ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Allow public to create appointments"
  ON appointments
  FOR INSERT
  TO public
  WITH CHECK (true);

CREATE POLICY "Allow users to view their own appointments"
  ON appointments
  FOR SELECT
  TO public
  USING (user_email IS NOT NULL);