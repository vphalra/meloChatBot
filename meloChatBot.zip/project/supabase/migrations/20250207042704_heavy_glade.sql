/*
  # Initial Schema Setup for ADHD Therapy Chatbot

  1. New Tables
    - `sessions`
      - `id` (uuid, primary key)
      - `user_id` (uuid, nullable)
      - `start_time` (timestamp)
      - `last_activity` (timestamp)
      - `context` (jsonb)
    
    - `messages`
      - `id` (uuid, primary key)
      - `session_id` (uuid, foreign key)
      - `content` (text)
      - `sender` (text)
      - `timestamp` (timestamp)
      - `intent` (text, nullable)
      - `entities` (jsonb, nullable)

  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users
    - Add policies for public access (for anonymous chat)
*/

-- Sessions table
CREATE TABLE IF NOT EXISTS sessions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id),
  start_time timestamptz DEFAULT now(),
  last_activity timestamptz DEFAULT now(),
  context jsonb DEFAULT '{}'::jsonb
);

ALTER TABLE sessions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Allow anonymous sessions"
  ON sessions
  FOR ALL
  USING (true);

-- Messages table
CREATE TABLE IF NOT EXISTS messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  session_id uuid REFERENCES sessions(id) NOT NULL,
  content text NOT NULL,
  sender text NOT NULL CHECK (sender IN ('user', 'bot', 'agent')),
  timestamp timestamptz DEFAULT now(),
  intent text,
  entities jsonb DEFAULT '{}'::jsonb
);

ALTER TABLE messages ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Allow messages for session"
  ON messages
  FOR ALL
  USING (true);