import { create } from 'zustand';
import type { ChatState, Message, ChatSession } from '../types';
import { supabaseService } from '../services/supabase.service';
import { nlpService } from '../services/nlp.service';
import { agentService } from '../services/agent.service';

interface ChatMetrics {
  totalMessages: number;
  avgResponseTime: number;
  handoffRate: number;
  successfulBookings: number;
}

interface ChatStore extends ChatState {
  addMessage: (content: string, sender: Message['sender']) => Promise<void>;
  startNewSession: () => Promise<void>;
  setTyping: (isTyping: boolean) => void;
  setAgentMode: (isAgentMode: boolean) => void;
  transferToAgent: () => Promise<void>;
  getMetrics: () => ChatMetrics;
}

export const useChatStore = create<ChatStore>((set, get) => ({
  messages: [],
  isTyping: false,
  isAgentMode: false,
  currentSession: null,
  user: null,
  showBooking: false,

  getMetrics: () => {
    const state = get();
    const messages = state.messages;
    
    // Calculate total messages
    const totalMessages = messages.length;
    
    // Calculate average response time
    let totalResponseTime = 0;
    let responseCount = 0;
    
    for (let i = 1; i < messages.length; i++) {
      if (messages[i].sender === 'bot' || messages[i].sender === 'agent') {
        const responseTime = messages[i].timestamp.getTime() - messages[i-1].timestamp.getTime();
        totalResponseTime += responseTime;
        responseCount++;
      }
    }
    
    const avgResponseTime = responseCount > 0 ? totalResponseTime / responseCount : 0;
    
    // Calculate handoff rate
    const handoffs = messages.filter(m => m.sender === 'agent').length;
    const handoffRate = totalMessages > 0 ? handoffs / totalMessages : 0;
    
    // Count successful bookings (redirects to booking page)
    const successfulBookings = messages.filter(m => 
      m.content.includes('Redirecting you to our booking page')
    ).length;
    
    return {
      totalMessages,
      avgResponseTime,
      handoffRate,
      successfulBookings
    };
  },

  transferToAgent: async () => {
    const state = get();
    try {
      await agentService.transferToAgent(state.messages);
      set({ isAgentMode: true });
    } catch (error) {
      console.error('Error transferring to agent:', error);
    }
  },

  addMessage: async (content: string, sender: Message['sender']) => {
    const state = get();
    if (!state.currentSession) {
      await get().startNewSession();
    }

    const message: Message = {
      id: crypto.randomUUID(),
      content,
      sender,
      timestamp: new Date(),
      sessionId: state.currentSession!.id
    };

    set(state => ({
      messages: [...state.messages, message]
    }));

    await supabaseService.saveMessage(message);

    if (sender === 'user') {
      set({ isTyping: true });
      
      // Check for booking-related keywords
      const bookingKeywords = ['book', 'appointment', 'schedule', 'booking', 'session'];
      const isBookingRequest = bookingKeywords.some(keyword => 
        content.toLowerCase().includes(keyword)
      );

      if (isBookingRequest) {
        const botMessage: Message = {
          id: crypto.randomUUID(),
          content: "I'll help you book an appointment right away. Redirecting you to our booking page now.",
          sender: 'bot',
          timestamp: new Date(),
          sessionId: state.currentSession!.id
        };
        
        set(state => ({
          messages: [...state.messages, botMessage],
          isTyping: false
        }));
        
        await supabaseService.saveMessage(botMessage);
        window.location.href = 'https://www.hellomelo.co/booking/';
        return;
      }
      
      const nlpResponse = await nlpService.processMessage(content);
      
      if (nlpResponse.intent === 'booking') {
        const botMessage: Message = {
          id: crypto.randomUUID(),
          content: "I'll help you schedule an appointment. Redirecting you to our booking page now.",
          sender: 'bot',
          timestamp: new Date(),
          sessionId: state.currentSession!.id
        };
        
        set(state => ({
          messages: [...state.messages, botMessage],
          isTyping: false
        }));
        
        await supabaseService.saveMessage(botMessage);
        window.location.href = 'https://www.hellomelo.co/booking/';
      } else if (nlpResponse.requiresAgent) {
        await get().transferToAgent();
        const agentMessage: Message = {
          id: crypto.randomUUID(),
          content: "Connecting you with a human agent now...",
          sender: 'agent',
          timestamp: new Date(),
          sessionId: state.currentSession!.id
        };
        set(state => ({
          messages: [...state.messages, agentMessage],
          isTyping: false
        }));
        await supabaseService.saveMessage(agentMessage);
      } else if (nlpResponse.suggestedResponse) {
        const botMessage: Message = {
          id: crypto.randomUUID(),
          content: nlpResponse.suggestedResponse,
          sender: 'bot',
          timestamp: new Date(),
          sessionId: state.currentSession!.id,
          intent: nlpResponse.intent,
          entities: nlpResponse.entities
        };
        set(state => ({
          messages: [...state.messages, botMessage],
          isTyping: false
        }));
        await supabaseService.saveMessage(botMessage);
      }
    }
  },

  startNewSession: async () => {
    const session = await supabaseService.createSession();
    set({ currentSession: session });
    const initialMessage: Message = {
      id: crypto.randomUUID(),
      content: "Hi there! I'm Melody, your virtual assistant. How can I help today?",
      sender: 'bot',
      timestamp: new Date(),
      sessionId: session.id
    };
    set(state => ({
      messages: [initialMessage]
    }));
    await supabaseService.saveMessage(initialMessage);
  },

  setTyping: (isTyping: boolean) => set({ isTyping }),
  setAgentMode: (isAgentMode: boolean) => set({ isAgentMode })
}));