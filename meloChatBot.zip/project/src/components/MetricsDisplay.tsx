import React from 'react';
import { BarChart3, Clock, Users, Calendar } from 'lucide-react';
import { useChatStore } from '../store/chatStore';

export const MetricsDisplay: React.FC = () => {
  const metrics = useChatStore(state => state.getMetrics());

  return (
    <div className="bg-white rounded-lg shadow-lg p-4 grid grid-cols-2 md:grid-cols-4 gap-4">
      <div className="flex items-center space-x-3 p-3 bg-purple-50 rounded-lg">
        <BarChart3 className="w-8 h-8 text-purple-500" />
        <div>
          <p className="text-sm text-gray-600">Total Messages</p>
          <p className="text-lg font-semibold">{metrics.totalMessages}</p>
        </div>
      </div>

      <div className="flex items-center space-x-3 p-3 bg-blue-50 rounded-lg">
        <Clock className="w-8 h-8 text-blue-500" />
        <div>
          <p className="text-sm text-gray-600">Avg Response Time</p>
          <p className="text-lg font-semibold">
            {Math.round(metrics.avgResponseTime)}ms
          </p>
        </div>
      </div>

      <div className="flex items-center space-x-3 p-3 bg-green-50 rounded-lg">
        <Users className="w-8 h-8 text-green-500" />
        <div>
          <p className="text-sm text-gray-600">Handoff Rate</p>
          <p className="text-lg font-semibold">
            {(metrics.handoffRate * 100).toFixed(1)}%
          </p>
        </div>
      </div>

      <div className="flex items-center space-x-3 p-3 bg-yellow-50 rounded-lg">
        <Calendar className="w-8 h-8 text-yellow-500" />
        <div>
          <p className="text-sm text-gray-600">Bookings</p>
          <p className="text-lg font-semibold">{metrics.successfulBookings}</p>
        </div>
      </div>
    </div>
  );
};