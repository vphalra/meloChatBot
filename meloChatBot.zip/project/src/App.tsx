import React, { useRef, useEffect, useState } from 'react';
import { ChatMessage } from './components/ChatMessage';
import { ChatInput } from './components/ChatInput';
import { MetricsDisplay } from './components/MetricsDisplay';
import { Bot, HeadsetIcon, AlertCircle, Loader2, BarChart } from 'lucide-react';
import { useChatStore } from './store/chatStore';

function App() {
  const { 
    messages, 
    isTyping, 
    isAgentMode,
    addMessage, 
    startNewSession,
    setAgentMode,
    transferToAgent
  } = useChatStore();
  
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const [error, setError] = useState<string | null>(null);
  const [isInitializing, setIsInitializing] = useState(true);
  const [showMetrics, setShowMetrics] = useState(false);

  useEffect(() => {
    const initializeChat = async () => {
      try {
        setIsInitializing(true);
        await startNewSession();
        if (!import.meta.env.VITE_OPENAI_API_KEY) {
          setError('OpenAI API key is missing. Please add VITE_OPENAI_API_KEY to your environment variables.');
        }
      } catch (err) {
        setError('Please connect to Supabase to enable chat functionality.');
        console.error('Session initialization error:', err);
      } finally {
        setIsInitializing(false);
      }
    };

    initializeChat();
  }, []);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleUserMessage = async (content: string) => {
    try {
      if (content.toLowerCase().includes('speak to agent') || 
          content.toLowerCase().includes('talk to human') ||
          content.toLowerCase().includes('human agent')) {
        setAgentMode(true);
        await transferToAgent();
        await addMessage("Connecting you with a human agent now...", 'agent');
        return;
      }
      await addMessage(content, 'user');
    } catch (err) {
      setError('Unable to send message. Please try again.');
      console.error('Message sending error:', err);
    }
  };

  if (isInitializing) {
    return (
      <div className="min-h-screen bg-gray-100 flex items-center justify-center p-4">
        <div className="text-center">
          <Loader2 className="w-8 h-8 text-purple-500 animate-spin mx-auto mb-4" />
          <p className="text-gray-600">Getting Melody ready for you...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-100 flex items-center justify-center p-4">
      <div className="w-full max-w-2xl bg-white rounded-lg shadow-lg overflow-hidden">
        <div className="bg-purple-500 p-4 text-white flex items-center gap-2">
          <Bot className="w-6 h-6" />
          <h1 className="text-lg font-semibold">Melody</h1>
          {isAgentMode && (
            <div className="ml-auto flex items-center gap-2 bg-green-500 px-3 py-1 rounded-full text-sm">
              <HeadsetIcon className="w-4 h-4" />
              <span>Agent Mode</span>
            </div>
          )}
          <button
            onClick={() => setShowMetrics(!showMetrics)}
            className="ml-auto text-white hover:text-purple-100 transition-colors"
          >
            <BarChart className="w-5 h-5" />
          </button>
        </div>
        
        {showMetrics && <MetricsDisplay />}
        
        {error && (
          <div className="bg-red-50 border-l-4 border-red-500 p-4 flex items-center gap-3">
            <AlertCircle className="w-5 h-5 text-red-500 flex-shrink-0" />
            <div>
              <p className="text-red-700">{error}</p>
              {error.includes('OpenAI API key') && (
                <p className="text-sm text-red-600 mt-1">
                  Add VITE_OPENAI_API_KEY to your .env file to enable AI chat responses.
                </p>
              )}
              {error.includes('Supabase') && (
                <p className="text-sm text-red-600 mt-1">
                  Click the "Connect to Supabase" button in the top right corner to set up your database.
                </p>
              )}
            </div>
          </div>
        )}
        
        <div className="h-[500px] overflow-y-auto p-4 bg-gray-50">
          {messages.map((message) => (
            <ChatMessage key={message.id} message={message} />
          ))}
          {isTyping && (
            <div className="flex gap-2 text-gray-500 text-sm ml-10">
              <span className="animate-bounce">●</span>
              <span className="animate-bounce" style={{ animationDelay: '0.2s' }}>●</span>
              <span className="animate-bounce" style={{ animationDelay: '0.4s' }}>●</span>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>

        <div className="border-t border-gray-200 p-4 bg-white">
          <ChatInput 
            onSend={handleUserMessage} 
            disabled={isTyping || !!error} 
          />
        </div>
      </div>
    </div>
  );
}

export default App;