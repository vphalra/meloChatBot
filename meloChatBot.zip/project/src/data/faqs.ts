export const faqs = [
  {
    question: "How does Melo service work?",
    answer: "We are a platform that connects adults with ADHD with occupational therapists who provide solution-focused therapy, personalized with tangible and actionable steps to help you achieve your goals. Our occupational therapists adopt a proactive approach, providing remedial tools and techniques based on your unique situation and preferences. They help with practical aspects of managing your ADHD, from prioritization and overwhelming responsibilities to motivation for career advancement.",
    category: "general",
    keywords: ["how", "work", "service", "platform", "connect", "occupational", "therapy", "solution"]
  },
  {
    question: "What is occupational therapy?",
    answer: "Occupational therapy is about helping you excel in your daily life, both at work and outside of it. Think of it as a personal trainer for your productivity and well-being. Our licensed occupational therapists (OTs) provide a unique approach to managing ADHD that complements traditional talk therapy. While talk therapy focuses on emotional and psychological aspects, our OTs help you develop and implement practical strategies to navigate daily life challenges associated with ADHD.",
    category: "therapy",
    keywords: ["what", "occupational", "therapy", "ot", "treatment", "help"]
  },
  {
    question: "Why is there a copay?",
    answer: "Similar to psychotherapy, primary care, or specialist visits, each session has a copay. We're currently in-network with UnitedHealthcare, Cigna, and Aetna in Colorado. Depending on your insurance plan, the copay typically ranges from $0 to $40. In other states where we're live, we're actively contracting with major insurance plans. During this transition, sessions are available at a flat $40 fee—comparable to a typical copay.",
    category: "billing",
    keywords: ["copay", "cost", "fee", "payment", "insurance", "price"]
  },
  {
    question: "Which insurance providers does Melo accept?",
    answer: "We're in the process of contracting with major insurance plans, including BCBS, Cigna, and Aetna. Currently, we're in-network with UnitedHealthcare, Cigna, and Aetna in Colorado. For other states, we offer a flat $40 fee per session while we expand our insurance coverage.",
    category: "insurance",
    keywords: ["insurance", "provider", "accept", "cover", "plan", "network"]
  },
  {
    question: "Can I book a session first and then purchase a package?",
    answer: "Yes, you can. A single session option is available during booking, giving you flexibility in your choice. This allows you to experience our service before committing to a package.",
    category: "booking",
    keywords: ["book", "session", "package", "purchase", "single", "try"]
  }
];