import { createClient } from '@supabase/supabase-js';
import type { Message, ChatSession, User } from '../types';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseKey) {
  throw new Error(
    'Missing Supabase environment variables. Please click "Connect to Supabase" to set up your database.'
  );
}

class SupabaseService {
  private supabase = createClient(supabaseUrl, supabaseKey);

  async saveMessage(message: Message): Promise<void> {
    const { error } = await this.supabase
      .from('messages')
      .insert([{
        id: message.id,
        session_id: message.sessionId,
        content: message.content,
        sender: message.sender,
        timestamp: message.timestamp,
        intent: message.intent,
        entities: message.entities || {}
      }]);

    if (error) throw error;
  }

  async createSession(): Promise<ChatSession> {
    const session: ChatSession = {
      id: crypto.randomUUID(),
      startTime: new Date(),
      lastActivity: new Date(),
      context: {}
    };

    const { error } = await this.supabase
      .from('sessions')
      .insert([{
        id: session.id,
        start_time: session.startTime,
        last_activity: session.lastActivity,
        context: session.context
      }]);

    if (error) throw error;
    return session;
  }

  async updateSession(sessionId: string, context: Record<string, any>): Promise<void> {
    const { error } = await this.supabase
      .from('sessions')
      .update({ 
        last_activity: new Date(),
        context 
      })
      .eq('id', sessionId);

    if (error) throw error;
  }

  async getUser(userId: string): Promise<User | null> {
    const { data, error } = await this.supabase
      .from('users')
      .select('*')
      .eq('id', userId)
      .single();

    if (error) throw error;
    return data;
  }

  async createAppointment(appointmentData: {
    date: string;
    time: string;
    type: string;
    name: string;
    email: string;
    phone: string;
    insurance: string;
    status: string;
  }): Promise<{ error: Error | null }> {
    try {
      const { error } = await this.supabase
        .from('appointments')
        .insert([{
          user_email: appointmentData.email,
          date: appointmentData.date,
          time: appointmentData.time,
          type: appointmentData.type,
          name: appointmentData.name,
          phone: appointmentData.phone,
          insurance: appointmentData.insurance,
          status: appointmentData.status
        }]);

      return { error: error || null };
    } catch (error) {
      console.error('Appointment creation error:', error);
      return { error: error as Error };
    }
  }

  async sendConfirmationEmail(emailData: {
    to: string;
    name: string;
    date: string;
    time: string;
    type: string;
  }): Promise<{ error: Error | null }> {
    try {
      const { error } = await this.supabase.functions.invoke('send-confirmation-email', {
        body: JSON.stringify(emailData)
      });

      return { error: error || null };
    } catch (error) {
      console.error('Email sending error:', error);
      return { error: error as Error };
    }
  }
}

export const supabaseService = new SupabaseService();