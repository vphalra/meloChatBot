import OpenAI from 'openai';
import { NLPResponse } from '../types';
import { faqs } from '../data/faqs';

const SYSTEM_PROMPT = `You are Melody, an empathetic and knowledgeable ADHD therapy assistant. Your responses should be:
- Warm and understanding
- Clear and concise
- Focused on ADHD therapy and support
- Professional but conversational

When users ask about Melo's services, provide this clear explanation:
"Melo is a platform that connects adults with ADHD to occupational therapists who provide solution-focused therapy. We offer:
- Personalized therapy with tangible, actionable steps
- Practical strategies for managing ADHD in daily life
- Support for prioritization and overwhelming responsibilities
- Career advancement guidance
- Flat $40 fee per session while expanding insurance coverage"

When a user requests to speak with a human agent, immediately transfer them without asking for confirmation.

Context: You work for Melo, an ADHD therapy practice that:
- Connects adults with ADHD to occupational therapists
- Provides solution-focused therapy with tangible, actionable steps
- Offers services at a flat $40 fee while expanding insurance coverage
- Emphasizes practical, real-world strategies over just talk therapy

Always maintain a supportive and encouraging tone while being accurate about our services and pricing.`;

class NLPService {
  private openai: OpenAI | null = null;
  private isQuotaExceeded = false;
  private messageHistory: { role: 'user' | 'assistant' | 'system'; content: string }[] = [];
  private readonly MAX_HISTORY = 10;

  constructor() {
    const apiKey = import.meta.env.VITE_OPENAI_API_KEY;
    
    if (!apiKey || apiKey === 'sk-your-openai-api-key-here') {
      console.error('No valid API key found in environment variables');
      return;
    }

    if (!apiKey.startsWith('sk-')) {
      console.error('Invalid API key format. OpenAI API keys must start with "sk-"');
      return;
    }
    
    try {
      this.openai = new OpenAI({
        apiKey,
        dangerouslyAllowBrowser: true
      });
      this.messageHistory = [{ role: 'system', content: SYSTEM_PROMPT }];
      console.log('OpenAI client initialized successfully');
    } catch (error) {
      console.error('Error initializing OpenAI client:', error);
      this.openai = null;
    }
  }

  private matchFAQ(message: string): string | null {
    const normalizedMessage = message.toLowerCase();
    
    // Check for questions about what Melo does
    if (
      normalizedMessage.includes('what') && 
      normalizedMessage.includes('melo') && 
      (normalizedMessage.includes('do') || normalizedMessage.includes('is'))
    ) {
      return faqs[0].answer; // Return the FAQ about how Melo service works
    }
    
    // Try to find a matching FAQ based on keywords
    for (const faq of faqs) {
      const matchesKeyword = faq.keywords.some(keyword => 
        normalizedMessage.includes(keyword.toLowerCase())
      );
      
      if (matchesKeyword) {
        return faq.answer;
      }
    }
    
    // If no keyword match, try semantic matching with question
    for (const faq of faqs) {
      const questionWords = faq.question.toLowerCase().split(' ');
      const messageWords = normalizedMessage.split(' ');
      
      const commonWords = questionWords.filter(word => 
        messageWords.includes(word) && word.length > 3
      );
      
      if (commonWords.length >= 2) {
        return faq.answer;
      }
    }
    
    return null;
  }

  private detectAgentRequest(message: string): boolean {
    const agentKeywords = [
      'speak to agent',
      'talk to human',
      'human agent',
      'real person',
      'live agent',
      'speak with someone',
      'talk to a person',
      'connect me with someone',
      'transfer me',
      'speak to a representative'
    ];

    return agentKeywords.some(keyword => 
      message.toLowerCase().includes(keyword)
    );
  }

  async processMessage(message: string): Promise<NLPResponse> {
    // First check if we can answer from FAQs
    const faqAnswer = this.matchFAQ(message);
    if (faqAnswer) {
      return {
        intent: 'faq',
        confidence: 1,
        entities: {},
        requiresAgent: false,
        suggestedResponse: faqAnswer
      };
    }

    // Check for agent request
    if (this.detectAgentRequest(message)) {
      return {
        intent: 'transfer',
        confidence: 1,
        entities: {},
        requiresAgent: true,
        suggestedResponse: "Connecting you with a human agent now..."
      };
    }

    if (!this.openai || this.isQuotaExceeded) {
      return {
        intent: 'error',
        confidence: 1,
        entities: {},
        requiresAgent: true,
        suggestedResponse: "I apologize, but I'm having trouble accessing my knowledge base at the moment. I'll connect you with a human specialist right away."
      };
    }

    try {
      // Add user message to history
      this.messageHistory.push({ role: 'user', content: message });
      
      // Keep only the last MAX_HISTORY messages
      if (this.messageHistory.length > this.MAX_HISTORY) {
        this.messageHistory = [
          this.messageHistory[0], // Keep system prompt
          ...this.messageHistory.slice(-this.MAX_HISTORY + 1)
        ];
      }

      const completion = await this.openai.chat.completions.create({
        messages: this.messageHistory,
        model: 'gpt-3.5-turbo',
        temperature: 0.7,
        max_tokens: 300
      });

      const response = completion.choices[0].message.content;
      
      // Add assistant response to history
      this.messageHistory.push({ role: 'assistant', content: response });
      
      // Determine if we should transfer to a human agent
      const requiresAgent = 
        message.length > 150 || // Complex queries
        message.toLowerCase().includes('emergency') ||
        message.toLowerCase().includes('crisis') ||
        message.toLowerCase().includes('suicidal') ||
        message.toLowerCase().includes('medication') ||
        message.toLowerCase().includes('diagnosis') ||
        message.toLowerCase().includes('prescription') ||
        message.toLowerCase().includes('medical');

      return {
        intent: requiresAgent ? 'transfer' : 'chat',
        confidence: 0.9,
        entities: {},
        suggestedResponse: requiresAgent 
          ? "I'll connect you with a specialist right away for proper support and guidance."
          : response,
        requiresAgent
      };

    } catch (error: any) {
      console.error('NLP Service Error:', error);
      
      if (error?.error?.type === 'insufficient_quota') {
        this.isQuotaExceeded = true;
        return {
          intent: 'error',
          confidence: 1,
          entities: {},
          requiresAgent: true,
          suggestedResponse: "I apologize, but I'm currently experiencing technical limitations. I'll connect you with a human specialist right away."
        };
      }
      
      return {
        intent: 'error',
        confidence: 1,
        entities: {},
        requiresAgent: true,
        suggestedResponse: "I apologize for the inconvenience. I'll connect you with a specialist who can assist you better."
      };
    }
  }
}

export const nlpService = new NLPService();