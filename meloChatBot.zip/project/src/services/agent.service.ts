import { Message } from '../types';

class AgentService {
  private tawkToPropertyId: string | null = null;
  private isInitialized = false;

  initialize(propertyId: string) {
    this.tawkToPropertyId = propertyId;
    
    // Add Tawk.to script
    const script = document.createElement('script');
    script.async = true;
    script.src = 'https://embed.tawk.to/' + propertyId + '/default';
    script.charset = 'UTF-8';
    script.setAttribute('crossorigin', '*');
    document.head.appendChild(script);

    this.isInitialized = true;
  }

  async transferToAgent(messages: Message[]) {
    if (!this.isInitialized) {
      throw new Error('Agent service not initialized');
    }

    // Get chat history
    const chatHistory = messages
      .map(m => `${m.sender}: ${m.content}`)
      .join('\n');

    // Open Tawk.to chat window with history
    if (window.Tawk_API) {
      window.Tawk_API.maximize();
      window.Tawk_API.setAttributes({
        'Chat History': chatHistory
      }, function(error: any) {
        console.error('Error setting chat history:', error);
      });
    }
  }
}

export const agentService = new AgentService();

// Add Tawk.to types
declare global {
  interface Window {
    Tawk_API?: {
      maximize: () => void;
      setAttributes: (attributes: Record<string, any>, callback: (error: any) => void) => void;
    };
  }
}