export interface Message {
  id: string;
  content: string;
  sender: 'user' | 'bot' | 'agent';
  timestamp: Date;
  sessionId: string;
  intent?: string;
  entities?: Record<string, any>;
  metrics?: {
    responseTime: number;
    wasHandoff: boolean;
    wasBookingAttempt: boolean;
  };
}

export interface FAQ {
  question: string;
  answer: string;
  category: string;
  keywords: string[];
}

export interface ChatSession {
  id: string;
  userId?: string;
  startTime: Date;
  lastActivity: Date;
  context: Record<string, any>;
}

export interface ChatState {
  messages: Message[];
  isTyping: boolean;
  isAgentMode: boolean;
  currentSession: ChatSession | null;
  user: User | null;
  showBooking: boolean;
}

export interface User {
  id: string;
  email: string;
  preferences: UserPreferences;
}

export interface UserPreferences {
  notifications: boolean;
  language: string;
  theme: 'light' | 'dark';
}

export interface NLPResponse {
  intent: string;
  confidence: number;
  entities: Record<string, any>;
  suggestedResponse?: string;
  requiresAgent: boolean;
}

export interface Appointment {
  id: string;
  userId: string;
  therapistId: string;
  startTime: Date;
  endTime: Date;
  status: 'pending' | 'confirmed' | 'cancelled';
  type: 'initial' | 'followup';
  notes?: string;
}